import mysql.connector
import google.generativeai as ai
import hashlib
from flask import Flask, request, jsonify

app = Flask(__name__)

# Database connection
def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Suman@12345",  # TODO: replace with your real password
            database="finopilotAI"  # Changed to consistent case
        )
        return connection
    except mysql.connector.Error as err:
        print(f"Database connection failed: {err}")
        return None

# Function to hash password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Function to add user
def add_user(username, password, api_key):
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        hashed_password = hash_password(password)
        try:
            cursor.execute(
                'INSERT INTO users (username, password, api_key) VALUES (%s, %s, %s)',
                (username, hashed_password, api_key)
            )
            conn.commit()
        except mysql.connector.Error as err:
            print(f"Error adding user: {err}")
        finally:
            cursor.close()
            conn.close()

# Function to verify user credentials
def verify_user_credentials(username, password):
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        try:
            cursor.execute('SELECT password FROM users WHERE username = %s', (username,))
            stored_password = cursor.fetchone()
            if stored_password and stored_password[0] == hash_password(password):
                return True
        except mysql.connector.Error as err:
            print(f"Error verifying user: {err}")
        finally:
            cursor.close()
            conn.close()
    return False

# Function to chat with Gemini
def chat_with_gemini(username, password, prompt):
    if not verify_user_credentials(username, password):
        return "Invalid username or password."

    conn = get_db_connection()
    if not conn:
        return "Database connection error."
    
    cursor = conn.cursor()
    try:
        cursor.execute('SELECT api_key FROM users WHERE username = %s', (username,))
        result = cursor.fetchone()
        if not result:
            return "API key not found."
        
        api_key = result[0]
        ai.configure(api_key=api_key)
        model = ai.GenerativeModel("gemini-1.5-flash")
        response = model.generate_content(prompt)
        return response.text if hasattr(response, "text") else "No response received."
    except Exception as e:
        print(f"Error during chat: {e}")
        return "An error occurred while processing the request."
    finally:
        cursor.close()
        conn.close()

# Route to handle chat requests
@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()

    if not data:
        return jsonify({'error': 'Invalid JSON body'}), 400

    username = data.get('username')
    password = data.get('password')
    prompt = data.get('prompt')

    if not all([username, password, prompt]):
        return jsonify({'error': 'Missing fields: username, password, or prompt'}), 400
    
    response_text = chat_with_gemini(username, password, prompt)
    return jsonify({'response': response_text})

if __name__ == '__main__':
    app.run(debug=True)
