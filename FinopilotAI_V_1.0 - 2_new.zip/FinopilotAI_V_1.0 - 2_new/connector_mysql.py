import mysql.connector  


conn = mysql.connector.connect(
    host='localhost',            
    user='root',                 
    password='Suman@12345',
    database='finopilotai'
)

my_cursor = conn.cursor()



conn.commit()
conn.close()

print("Connection successfully created!")
