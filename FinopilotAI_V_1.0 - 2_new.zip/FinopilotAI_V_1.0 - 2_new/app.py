from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import mysql.connector
import google.generativeai as genai
import hashlib

app = Flask(__name__)
CORS(app)

# MySQL Connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Suman@12345",
    database="finopilotai"
)
cursor = db.cursor()

# API Key Configuration
genai.configure(api_key="AIzaSyDqJuicM95e7Pk80STJUF3JODYo5-bqhBw")
model = genai.GenerativeModel("gemini-1.5-flash")

# Function to hash password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@app.route('/')
def index():
    return render_template("register.html")

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get("username")
    email = data.get("email")
    mobile = data.get("mobile")
    dob = data.get("dob")
    address = data.get("address")
    profession = data.get("profession")
    organization = data.get("organization")
    password = data.get("password")

    if not all([username, email, mobile, dob, address, profession, organization, password]):
        return jsonify({"error": "All fields are required."}), 400

    try:
        # Insert into users
        hashed_password = hash_password(password)
        cursor.execute(""" 
            INSERT INTO users (username, email, mobile, dob, address, profession, organization, password) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s) 
        """, (username, email, mobile, dob, address, profession, organization, hashed_password))
        db.commit()
        return jsonify({"message": "User registered successfully"}), 200
    except mysql.connector.Error as err:
        db.rollback()
        return jsonify({"error": str(err)}), 500

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    hashed_password = hash_password(password)

    cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, hashed_password))
    user = cursor.fetchone()
    if user:
        return jsonify({"message": "Login successful"}), 200
    else:
        return jsonify({"error": "Invalid credentials"}), 401

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    prompt = data.get("prompt", "").strip()
    if not prompt:
        return jsonify({"error": "Prompt cannot be empty"}), 400
    try:
        response = model.generate_content(prompt)
        return jsonify({"response": response.text})
    except Exception as e:
        return jsonify({"error": f"Gemini error: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)